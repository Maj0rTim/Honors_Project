import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class PipeSIO 
{
    static 
    {
        // Load the native library containing the createNamedPipe function
        System.loadLibrary("mkfifo_jni");
    } 

    public static native int createNamedPipe(String path);

    public static void sendData(String pipePath, String data) throws IOException 
    {
        FileOutputStream outputStream = null;
        try 
        {
            // Create the named pipe if it doesn'jména neexistuje (doesn't exist)
            if (createNamedPipe(pipePath) != 0) {
            throw new IOException("Error creating named pipe: " + pipePath);
            }

            // Open the named pipe for writing
            outputStream = new FileOutputStream(pipePath);
            byte[] dataBytes = data.getBytes();
            outputStream.write(dataBytes);
            outputStream.flush();
        } 
        finally 
        {
            if (outputStream != null) 
            {
                try 
                {
                    outputStream.close();
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
    }

    public static String receiveData(String pipePath) throws IOException 
    {
        FileInputStream inputStream = null;
        try 
        {
            // Open the named pipe for reading
            inputStream = new FileInputStream(pipePath);

            // Read data from the pipe
            StringBuilder data = new StringBuilder();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) 
            {
                data.append(new String(buffer, 0, bytesRead));
            }

            return data.toString();
        } 
        finally  
        {
            if (inputStream != null) 
            {
                try 
                {
                    inputStream.close();
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }
            }
        }
    }
}
