import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class PipeNIO 
{
    static 
    {
        // Load the native library containing the createNamedPipe function
        System.loadLibrary("mkfifo_jni");
    }

    public static native int createNamedPipe(String path);

    public static void sendData(String pipePath, String data) throws IOException 
    {
        Path filePath = Paths.get(pipePath);
        try (FileChannel channel = FileChannel.open(filePath, StandardOpenOption.WRITE, StandardOpenOption.CREATE)) 
        {
            // Create the named pipe if it doesn't exist
            if (createNamedPipe(pipePath) != 0) 
            {
                throw new IOException("Error creating named pipe: " + pipePath);
            }

            byte[] dataBytes = data.getBytes();
            ByteBuffer buffer = ByteBuffer.wrap(dataBytes);
            while (buffer.hasRemaining()) 
            {
                channel.write(buffer);
            }
        }
    }

    public static String receiveData(String pipePath) throws IOException 
    {
        Path filePath = Paths.get(pipePath);
        try (FileChannel channel = FileChannel.open(filePath, StandardOpenOption.READ)) 
        {
            // Open the named pipe for reading
            StringBuilder data = new StringBuilder();
            ByteBuffer buffer = ByteBuffer.allocate(1024);
            int bytesRead;
            while ((bytesRead = channel.read(buffer)) != -1) 
            {
                buffer.flip(); // Prepare buffer for reading
                data.append(new String(buffer.array(), 0, bytesRead));
                buffer.clear(); // Reset buffer for next read
            }

            return data.toString();
        }
    }
}
