public class prototype_pipe 
{
    public static void main(String[] args) 
    {
        
    }
}
