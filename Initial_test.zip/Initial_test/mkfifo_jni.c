#include <jni.h>
#include <stdio.h>
#include <sys/stat.h>

JNIEXPORT int JNICALL Java_com_example_MyJniClass_createNamedPipe(JNIEnv *env, jobject obj, jstring path) 
{
  const char *pipe_path = (*env)->GetStringUTFChars(env, path, NULL);
  if (pipe_path == NULL) {
    return -1; // Handle UTF conversion error
  }

  mode_t mode = 0666;

  int ret = mkfifo(pipe_path, mode);

  (*env)->ReleaseStringUTFChars(env, path, pipe_path);

  if (ret == -1) {
    perror("mkfifo");
    return -1;
  }

  return 0;
}